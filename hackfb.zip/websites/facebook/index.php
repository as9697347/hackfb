<?php
include 'ip.php';
header('Location: login');
exit
?>
